<?php

return [
    //Twig\Extra\TwigExtraBundle\TwigExtraBundle::class => ['all' => true],
];
