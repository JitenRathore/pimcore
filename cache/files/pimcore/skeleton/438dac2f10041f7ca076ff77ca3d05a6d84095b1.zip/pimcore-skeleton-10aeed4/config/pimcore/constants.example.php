<?php

// to use this file you have to rename it to constants.php
// you can use this file to overwrite the constants defined in lib/Bootstrap.php

// EXAMPLES:

// Overwrite locations
//define("PIMCORE_ASSET_DIRECTORY", "/custom/path/to/assets");
//define("PIMCORE_TEMPORARY_DIRECTORY", "/my/tmp/path");
