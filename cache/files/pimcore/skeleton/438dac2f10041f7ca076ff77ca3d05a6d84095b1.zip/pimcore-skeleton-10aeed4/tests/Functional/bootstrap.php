<?php

// We want to use the global bootstrap, but customize the setup a bit to run tests with a larger scope.
require_once dirname(__DIR__) . '/bootstrap.php';

// TODO: Add custom bootstrap code that only applies to integration tests here.
