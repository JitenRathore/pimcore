<?php

declare(strict_types=1);

namespace Codeception\Exception;

class Notice extends Error
{
}
